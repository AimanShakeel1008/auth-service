Flyway migrations should be placed here using the pattern:
V{version}__{description}.sql e.g. V1__initial_schema.sql

Do not store secrets in migration files.
