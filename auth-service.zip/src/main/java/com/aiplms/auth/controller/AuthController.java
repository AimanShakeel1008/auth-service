package com.aiplms.auth.controller;

import com.aiplms.auth.config.AuthProperties;
import com.aiplms.auth.dto.v1.*;
import com.aiplms.auth.entity.RefreshToken;
import com.aiplms.auth.exception.ErrorResponse;
import com.aiplms.auth.exception.Exceptions;
import com.aiplms.auth.mapper.UserMapper;
import com.aiplms.auth.repository.UserRepository;
import com.aiplms.auth.security.JwtService;
import com.aiplms.auth.service.*;
import com.aiplms.auth.util.TokenUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final RefreshTokenService refreshTokenService;
    private final JwtService jwtService;
    private final AuthProperties authProperties;
    private final TokenBlacklistService tokenBlacklistService;
    private final EmailVerificationService emailVerificationService;
    private final PasswordResetService passwordResetService;



    @PostMapping("/register")
    public ResponseEntity<ApiResponse<Map<String, Object>>> register(@Valid @RequestBody RegisterRequestDto request) {
        Map<String, Object> data = authService.register(request);
        ApiResponse<Map<String, Object>> body = new ApiResponse<>("AUTH_001", "User registered successfully", data);
        return ResponseEntity.ok(body);
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<Map<String, Object>>> login(@Valid @RequestBody LoginRequestDto request) {
        Map<String, Object> data = authService.login(request);
        ApiResponse<Map<String, Object>> body = new ApiResponse<>("AUTH_002", "Login successful", data);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<UserResponseDto>> me() {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal() == null
                || "anonymousUser".equals(auth.getPrincipal())) {
            throw Exceptions.unauthorized("Authentication required");
        }

        String principalName = auth.getName();

        // Resolve user by username first, then by email
        var userOpt = userRepository.findByUsernameIgnoreCase(principalName);
        if (userOpt.isEmpty()) {
            userOpt = userRepository.findByEmailIgnoreCase(principalName);
        }

        var user = userOpt.orElseThrow(() -> Exceptions.unauthorized("Authenticated user not found"));

        var dto = userMapper.toUserResponse(user);

        var body = new ApiResponse<>("AUTH_011", "Current user retrieved", dto);
        return ResponseEntity.ok(body);
    }

    /**
     * Refresh endpoint with rotation.
     */
    @PostMapping("/token/refresh")
    public ResponseEntity<ApiResponse<TokenResponseDto>> refreshToken(
            @Valid @RequestBody RefreshRequestDto request
    ) {
        String incoming = request.getRefreshToken();
        if (incoming == null || incoming.isBlank()) {
            throw Exceptions.badRequest("Missing refresh token");
        }

        // compute hash using TokenUtil (existing util)
        String hash = TokenUtil.sha256Hex(incoming);

        // find persisted refresh token by hash
        var opt = refreshTokenService.findByHash(hash);
        if (opt.isEmpty()) {
            // token not found -> invalid or reuse
            throw Exceptions.unauthorized("Invalid refresh token");
        }

        RefreshToken stored = opt.get();

        // check revoked / expired
        if (stored.isRevoked()) {
            // possible reuse / replay — return unauthorized
            // TODO: log details for audit; optionally revoke all tokens for user
            throw Exceptions.unauthorized("Refresh token has been revoked");
        }

        if (stored.getExpiresAt().isBefore(Instant.now())) {
            // expired
            throw Exceptions.unauthorized("Refresh token expired");
        }

        // rotation: revoke current token
        refreshTokenService.revoke(stored);

        // create new refresh token (expiry using authProperties or a TTL; AuthServiceImpl uses authProperties)
        Instant newExpiry = Instant.now().plus(authProperties.getRefreshTokenTtl());
        var createResult = refreshTokenService.createForUser(stored.getUser(), newExpiry);

        // create new access token
        JwtService.AccessToken accessToken = jwtService.createAccessToken(stored.getUser());

        TokenResponseDto resp = new TokenResponseDto(
                accessToken.getToken(),
                accessToken.getExpiresAtIso(),
                createResult.getPlainToken(),
                newExpiry.toString()
        );

        var body = new ApiResponse<>("AUTH_013", "Token refreshed", resp);
        return ResponseEntity.ok(body);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(
            @Valid @RequestBody LogoutRequestDto request,
            HttpServletRequest httpRequest,
            @RequestHeader(name = "Authorization", required = false) String authorizationHeader
    ) {
        // 1) Blacklist access token from Authorization header (if present)
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            String accessToken = authorizationHeader.substring(7).trim();
            try {
                // delegate to blacklist service
                tokenBlacklistService.blacklistAccessToken(accessToken);
            } catch (Exception ex) {
                // do not fail logout if blacklist fails; log and continue (but surface mild error if you want)
                log.warn("Failed to blacklist access token during logout", ex);
            }
        }

        // 2) Revoke refresh token if provided
        if (request != null && request.getRefreshToken() != null && !request.getRefreshToken().isBlank()) {
            String providedRefresh = request.getRefreshToken();
            String hash = TokenUtil.sha256Hex(providedRefresh);
            java.util.Optional<RefreshToken> refreshOpt = refreshTokenService.findByHash(hash);
            if (refreshOpt.isPresent()) {
                // revoke via refresh token service
                refreshTokenService.revoke(refreshOpt.get());
            } else {
                // no-op if not found
                log.debug("Logout requested for unknown refresh token (hash={})", hash);
            }
        }

        // 3) Clear Spring Security context for safety
        SecurityContextHolder.clearContext();

        var body = new ApiResponse<>("AUTH_014", "Logged out", null);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/verify-email")
    public ResponseEntity<?> verifyEmail(@RequestParam("token") String token, HttpServletRequest request) {
        boolean ok = emailVerificationService.verifyToken(token);
        if (!ok) {

            var err = ErrorResponse.builder()
                    .timestamp(OffsetDateTime.now())
                    .status(400).errorCode("AUTH_ERR_015")
                    .message("Invalid or expired verification token")
                    .path(request.getRequestURI())
                    .build();

            return ResponseEntity.badRequest().body(err);
        }

        var body = new ApiResponse<>("AUTH_015", "Email verified successfully", null);
        return ResponseEntity.ok(body);
    }

    /**
     * Request password reset (send email with token).
     */
    @PostMapping("/password-reset/request")
    public ResponseEntity<?> passwordResetRequest(
            @Valid @RequestBody PasswordResetRequestDto requestDto
    ) {
        // Do not reveal whether email exists. Service will send email if account exists.
        passwordResetService.createAndSendToken(requestDto.getEmail());

        var body = new ApiResponse<>("AUTH_016", "If an account with that email exists, a password reset link has been sent", null);
        return ResponseEntity.ok(body);
    }

    /**
     * Confirm password reset (token + new password).
     */
    @PostMapping("/password-reset/confirm")
    public ResponseEntity<?> passwordResetConfirm(
            @Valid @RequestBody PasswordResetConfirmRequestDto requestDto,
            HttpServletRequest request
    ) {
        if (!requestDto.getNewPassword().equals(requestDto.getNewPasswordConfirm())) {
            var err = ErrorResponse.builder()
                    .timestamp(OffsetDateTime.now())
                    .status(400)
                    .errorCode("AUTH_ERR_016")
                    .message("Passwords do not match")
                    .path(request.getRequestURI())
                    .build();
            return ResponseEntity.badRequest().body(err);
        }

        boolean ok = passwordResetService.confirmReset(requestDto.getToken(), requestDto.getNewPassword());
        if (!ok) {
            var err = ErrorResponse.builder()
                    .timestamp(OffsetDateTime.now())
                    .status(400)
                    .errorCode("AUTH_ERR_017")
                    .message("Invalid or expired password reset token")
                    .path(request.getRequestURI())
                    .build();
            return ResponseEntity.badRequest().body(err);
        }

        var body = new ApiResponse<>("AUTH_017", "Password has been reset successfully", null);
        return ResponseEntity.ok(body);
    }
}

